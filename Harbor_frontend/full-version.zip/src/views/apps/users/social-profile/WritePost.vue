<script setup lang="ts"></script>

<template>
  <v-card variant="flat" class="pa-5">
    <v-textarea variant="outlined" color="primary" name="input-7-4" label="Whats on your mind, Larry ?" rows="4"></v-textarea>
    <div class="d-flex">
      <v-btn color="secondary" variant="text" prepend-icon="mdi-attachment">Gallery</v-btn>
      <v-btn color="secondary" variant="flat" class="ml-auto" prepend-icon="mdi-layers-outline">Post</v-btn>
    </div>
  </v-card>
</template>
