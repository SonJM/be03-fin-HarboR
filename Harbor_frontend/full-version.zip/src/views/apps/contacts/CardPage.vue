<script setup lang="ts">
import ContactCardList from '@/components/apps/contact/ContactCardList.vue';
</script>
<template>
  <ContactCardList />
</template>
