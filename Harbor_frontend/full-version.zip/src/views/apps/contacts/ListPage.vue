<script setup lang="ts">
import ContactList from '@/components/apps/contact/ContactList.vue';
</script>
<template>
  <ContactList />
</template>
